// import logo from './logo.svg';
// import './App.css';
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Header from './Components/Header';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import LogIn from './Components/LogIn';
import SignUp from './Components/SignUp';
import Dashboard from './Components/Dashboard';
import AddEvent from './Components/AddEvent';
import Profile from "./Components/Profile";


function App() {
  let time = 5000
  return (
    <div className="App">
      <ToastContainer
        position="bottom-right"
        autoClose={5000}
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
        theme="colored"
        closeButton={
          <button
            style={{
              width: "30px",
              backgroundColor: "inherit",
              border: "none",
              color: "white",
            }}
          >
            X
          </button>
        }
      />
      <Router>
        <Header/>
        <Routes>
          <Route exact path='/' element={<Dashboard />}></Route>
          <Route exact path='/login' element={<LogIn/>}></Route>
          <Route exact path='/signup' element={<SignUp/>}></Route> 
          <Route exact path='/addevent' element={<AddEvent/>}></Route>
          <Route exact path='/profile' element={<Profile/>}></Route>
        </Routes>
        
      </Router>
    </div> 
  );
}

export default App;
