import React, { useState } from 'react';
import { styled } from '@mui/material/styles';
import Card from '@mui/material/Card';
import CardHeader from '@mui/material/CardHeader';
import CardMedia from '@mui/material/CardMedia';
import CardContent from '@mui/material/CardContent';
import CardActions from '@mui/material/CardActions';
import Collapse from '@mui/material/Collapse';
import Avatar from '@mui/material/Avatar';
import IconButton from '@mui/material/IconButton';
import Typography from '@mui/material/Typography';
import { red } from '@mui/material/colors';
import FavoriteIcon from '@mui/icons-material/Favorite';
import { FavoriteOutlined, FavoriteBorderOutlined } from '@mui/icons-material';
import ChatBubbleOutlined from '@mui/icons-material/ChatBubbleOutlined'
import ShareIcon from '@mui/icons-material/Share';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import { RWebShare } from "react-web-share";
import { TextField, Button, Box, Divider } from '@mui/material';
import { SendOutlined } from '@mui/icons-material';
import axios from 'axios'

const ExpandMore = styled((props) => {
  const { expand, ...other } = props;
  return <IconButton {...other} />;
})(({ theme, expand }) => ({
  transform: !expand ? 'rotate(0deg)' : 'rotate(180deg)',
  marginLeft: 'auto',
  transition: theme.transitions.create('transform', {
    duration: theme.transitions.duration.shortest,
  }),
}));



export default function Event({ data }) {
  const [expanded, setExpanded] = React.useState(false);
  const [comments, setComments] = React.useState(["Great event!", "Awesome event!"]);
  const [newComment, setNewComment] = useState('');
  const [liked, setLiked] = useState(false);

  const handleClick = () => {
    try {
      setLiked(!liked);
      if (liked) {

      } else {

      }
    } catch (error) {
      console.log(error)
    }
  };

  const handleSubmit = async (event) => {
    try{
      debugger
      event.preventDefault();
      let event_id = 1
      let user_id = 1
      let response = await axios.post('/addComment', {
         event_id, user_id, comment : newComment
      })
      console.log("Comments : ",response)
      setComments([...comments, newComment]);
      setNewComment('');
    }catch(error){
        console.log(error)
    }
  }
  const handleExpandClick = () => {
    setExpanded(!expanded);
  };

  return (
    <Card sx={{ maxWidth: 752, border: '1px solid rgba(0,0,0,0.4)' }}>
      <CardHeader sx={{ marginBottom: '-15px' }}
        avatar={
          <Avatar sx={{ bgcolor: red[500] }} aria-label="recipe">
            E
          </Avatar>
        }
        title={"Siddhant Agrawal"}
        subheader={new Date(data.createdAt * 1000).toLocaleString()}
      />
      <CardContent>
        <Typography variant="body1" color="text.secondary">
          <span style={{ "fontWeight": "bold" }}>Name</span>  : {data.event_name} <br />
          <span style={{ "fontWeight": "bold" }}>Place</span>  : {data.venue + "," + data.city + "," + data.state} <br />
          <span style={{ "fontWeight": "bold" }}>Date & Time</span>  : {new Date(data.event_date * 1000).toLocaleString()} <br />
          <span style={{ "fontWeight": "bold" }}>Description</span>  : {data.event_description}
        </Typography>
      </CardContent>
      <CardMedia
        component="img"
        height="194"
        image="https://helpx.adobe.com/content/dam/help/en/photoshop/using/convert-color-image-black-white/jcr_content/main-pars/before_and_after/image-before/Landscape-Color.jpg"
        alt="Image"
        sx={{ px: 2 }}
      />

      <CardActions style={{ "display": "flex", "justifyContent": "space-evenly" }}>

        <IconButton aria-label="like" onClick={handleClick} style={{ width: "32.5%" }} color="error">
          {liked ? <FavoriteOutlined /> : <FavoriteBorderOutlined />}
        </IconButton>
        <IconButton aria-label="comment" style={{ width: "32.5%", color: "#537188" }} 
          onClick={() => handleExpandClick()}>
          <ChatBubbleOutlined />
        </IconButton>

        <RWebShare
          data={{
            text: "Events are for everyone",
            url: "https://on.natgeo.com/2zHaNup",
            title: "Eventro",
          }}
          onClick={() => console.log("shared successfully!")}
        >

          <IconButton aria-label="share" color="info" style={{ width: "32.5%" }}>
            <ShareIcon />
          </IconButton>
        </RWebShare>

      </CardActions>
      <Collapse in={expanded} timeout="auto" unmountOnExit>
        <CardContent>
          <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
            {/* <Typography variant="h6" sx={{ mt: 0, mb: 1 }}>Comments</Typography> */}
            <Divider sx={{ width: '100%', mb: 2 }} />
            <form onSubmit={async(e) => await handleSubmit(e)} style={{ width: '100%' }}>
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <Avatar sx={{ mr: 2 }}>U</Avatar>
                <TextField
                  id="comment"
                  label="Write a comment"
                  variant="outlined"
                  fullWidth
                  value={newComment}
                  onChange={(event) => setNewComment(event.target.value)}
                />
                <IconButton type="submit" sx={{ ml: 2 }}>
                  <SendOutlined />
                </IconButton>

              </Box>
            </form>

          </Box>
          <Divider sx={{ width: '100%', mb: 2, mt: 2 }} />
          {comments.map((comment, index) => (
            <Box key={index} sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
              <Avatar sx={{ mr: 2 }}>U</Avatar>
              <Typography variant="body1">{comment}</Typography>
            </Box>
          ))}
        </CardContent>
      </Collapse>
    </Card>
  );
}